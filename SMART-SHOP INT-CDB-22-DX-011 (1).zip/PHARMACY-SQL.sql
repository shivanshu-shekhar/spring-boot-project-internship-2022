Create database pharmacy
