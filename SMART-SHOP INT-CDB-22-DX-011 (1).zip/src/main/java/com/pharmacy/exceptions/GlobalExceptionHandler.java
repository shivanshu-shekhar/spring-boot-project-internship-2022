package com.pharmacy.exceptions;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

//@ControllerAdvice
public class GlobalExceptionHandler {

  private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

  @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler(javax.el.PropertyNotFoundException.class)
 	public String handlePropertyNotException(final Exception ex,
 			final HttpServletRequest request,Model model) {
 		log.error("Error Message : "+ex.getMessage());
 		log.error("URI : "+request.getRequestURI()); 
 		model.addAttribute("error", ex.getMessage());
 		model.addAttribute("uri", request.getRequestURI());
 		return "error";
 		//. return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.BAD_REQUEST);
 	}
  
  @ResponseStatus(code = HttpStatus.INTERNAL_SERVER_ERROR)
  @ExceptionHandler(Exception.class)
	public String handleException(final Exception ex,
			final HttpServletRequest request,Model model) {
		log.error("Error Message : "+ex.getLocalizedMessage());
		log.error("URI : "+request.getRequestURI()); 
		model.addAttribute("error", ex.getMessage());
 		model.addAttribute("uri", request.getRequestURI());
		return "error";
		// return new ResponseEntity<Object>(ex.getMessage(),HttpStatus.BAD_REQUEST);
	}

}
