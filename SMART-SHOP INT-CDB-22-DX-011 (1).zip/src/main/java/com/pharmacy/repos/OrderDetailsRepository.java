package com.pharmacy.repos;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pharmacy.models.OrderDetails;
import com.pharmacy.models.ProductSalesCount;

@Repository
@Transactional
public interface OrderDetailsRepository extends JpaRepository<OrderDetails, Integer>{
	
	@Query("SELECT o FROM OrderDetails o WHERE o.orderid=?1")
	List<OrderDetails> findByOrderid(int orderid);
		
	void deleteByOrderid(int orderid);
	
	@Query("SELECT new com.pharmacy.models.ProductSalesCount(p.product,sum(p.qty)) from OrderDetails p GROUP BY p.product")
	List<ProductSalesCount> countProductBySales();
}
