package com.pharmacy.repos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pharmacy.models.ProductBatch;
import com.pharmacy.models.Purchase;

@Repository
public interface ProductBatchRepository extends JpaRepository<ProductBatch, Integer> {

	List<ProductBatch> findByProdid(int prodid);
	
	List<ProductBatch> findByPurchase(Purchase p);
	
	List<ProductBatch> findTop10ByQtyGreaterThanOrderByExpirydate(int qty);
}
