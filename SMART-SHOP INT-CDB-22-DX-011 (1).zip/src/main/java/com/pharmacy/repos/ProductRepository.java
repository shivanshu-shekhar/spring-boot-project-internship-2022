package com.pharmacy.repos;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pharmacy.models.Product;
import com.pharmacy.models.ProductCount;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
	
	Page<Product> findByDeletedOrderByProdidDesc(boolean isdeleted,Pageable pageable);
	
	List<Product> findByDeletedOrderByProdidDesc(boolean isdeleted);
	
	List<Product> findByCatidOrderByProdidDesc(int catid);

	@Query("SELECT new com.pharmacy.models.ProductCount(p.category,count(p.category)) from Product p GROUP BY p.category")
	List<ProductCount> countProductByCategory();
}
