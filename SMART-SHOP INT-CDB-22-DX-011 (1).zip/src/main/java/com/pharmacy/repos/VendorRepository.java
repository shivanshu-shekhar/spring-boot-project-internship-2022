package com.pharmacy.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.pharmacy.models.Vendor;

@Repository
public interface VendorRepository extends JpaRepository<Vendor, Integer> {

}
