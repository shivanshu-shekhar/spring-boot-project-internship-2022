package com.pharmacy.controllers;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.multipart.MultipartFile;

import com.pharmacy.exceptions.GlobalExceptionHandler;
import com.pharmacy.models.Category;
import com.pharmacy.models.HelpDesk;
import com.pharmacy.models.Order;
import com.pharmacy.models.OrderDetails;
import com.pharmacy.models.Product;
import com.pharmacy.models.ProductBatch;
import com.pharmacy.models.Purchase;
import com.pharmacy.models.Vendor;
import com.pharmacy.service.AdminUserService;
import com.pharmacy.service.CategoryService;
import com.pharmacy.service.CustomerService;
import com.pharmacy.service.HelpDeskService;
import com.pharmacy.service.OrderDetailsService;
import com.pharmacy.service.OrderService;
import com.pharmacy.service.ProductBatchService;
import com.pharmacy.service.ProductService;
import com.pharmacy.service.PurchaseService;
import com.pharmacy.service.VendorService;

@Controller
public class AdminController {
	
	@Autowired
	private CategoryService catsrv;
	@Autowired private ProductService prodsrv;
	@Autowired private CustomerService custsrv;
	@Autowired private AdminUserService adminsrv;
	@Autowired private OrderService ordersrv;
	@Autowired private OrderDetailsService odsrv;
	@Autowired private HelpDeskService hdsrv;
	@Autowired private VendorService vsrv;
	@Autowired private PurchaseService pursrv;
	@Autowired private ProductBatchService pbsrv;
	@Autowired private HttpSession session;
	
	private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		model.addAttribute("totalusers", custsrv.allCustomers().size());
		model.addAttribute("totalproducts", prodsrv.countProducts());
		model.addAttribute("totalcategories", catsrv.totalCategories());
		model.addAttribute("totalorders", ordersrv.allOrders().size());		
		model.addAttribute("cats", prodsrv.getChartData().keySet().stream().map(x->x="'"+x+"'").collect(Collectors.toList()));
		model.addAttribute("counts", prodsrv.getChartData().values());
		model.addAttribute("prods", odsrv.getChartData().keySet().stream().map(x->x="'"+x+"'").collect(Collectors.toList()));
		model.addAttribute("pcounts", odsrv.getChartData().values());
		return "dashboard";
	}
	
	@GetMapping("/delbatch/{id}")
	public String deleteBatchItem(@PathVariable("id") int id) {
		pbsrv.deleteBatch(id);
		return "redirect:/purchase";
	}
	
	@GetMapping("/users")
	public String customerlist(Model model){	
		model.addAttribute("users",custsrv.allCustomers());
		return "customers";
	}
	
	@GetMapping("/orders")
	public String orderslist(Model model){
		model.addAttribute("orders", ordersrv.allOrders());
		return "orders";
	}
	
	@GetMapping("/confirm/{id}")
	public String confirmOrder(@PathVariable("id") int orderid){
		ordersrv.confirmOrder(orderid);
		session.setAttribute("msg", "Order Confirmed successfully");
		return "redirect:/orders";
	}
	
	@GetMapping("/details/{id}")
	public String orderdetails(@PathVariable("id") int orderid, Model model){
		Order order=ordersrv.getOrderDetails(orderid);
		List<OrderDetails> odlist=odsrv.allItemsinOrder(orderid);
		System.out.println("Total items : "+odlist.size());
		model.addAttribute("cats", catsrv.getAllCategories());
		model.addAttribute("o", order);
		model.addAttribute("items",odlist);		
		model.addAttribute("cqty", odlist.size());
		return "orderdetails";
	}
	
	@GetMapping("/reports")
	public String report(Model model){
		model.addAttribute("items", pbsrv.reportItems());
		model.addAttribute("thismonth",LocalDate.now());
		return "reports";
	}
	
	@GetMapping("/purchases")
	public String purchaselist(Model model) {
		model.addAttribute("items", pursrv.allPurchases());
		return "purchases";
	}
	
	@GetMapping("/purchase")
	public String purchases(Model model){	
		model.addAttribute("vendors", vsrv.allVendors());
		model.addAttribute("prods", prodsrv.allProducts());
		model.addAttribute("items",pursrv.allPurchases());
		model.addAttribute("batches", pbsrv.itemsToPurchase());
		return "purchase";
	}
	
	@PostMapping("/purchase")
	public String purchaseSave(Purchase pur) {
		pursrv.savePurchase(pur);
		return "redirect:/purchase";
	}
	
	@PostMapping("/saveBatch")
	public String saveBatch(ProductBatch pb,String mfg,String exp) {
		System.err.println(LocalDate.parse(exp+"-01"));
		System.err.println(LocalDate.parse(mfg+"-01"));
		pb.setExpirydate(LocalDate.parse(exp+"-01"));
		pb.setMfgdate(LocalDate.parse(mfg+"-01"));		
		System.err.println(pb.getExpirydate());
		System.err.println(pb.getMfgdate());
		pbsrv.saveBatch(pb);
		return "redirect:/purchase";
	}
	
	@GetMapping("/changepwd")
	public String changepassword(){		
		return "achangepwd";
	}
	
	@GetMapping("/tickets")
	public String helpdesk(Model model) {
		model.addAttribute("items", hdsrv.getAllRequest());
		return "tickets";
	}
	
	@PostMapping("/tickets")
	public String tickets(int id,String reply) {
		HelpDesk hd= hdsrv.findRequestById(id);
		hd.setReply(reply);
		hd.setStatus("Processed");
		hdsrv.saveRequest(hd);
		session.setAttribute("msg", "Reply saved successfully");
		return "redirect:/tickets";
	}
	
	@GetMapping("/vendors")
	public String vendors(Model model) {
		model.addAttribute("items", vsrv.allVendors());
		return "vendors";
	}
	
	@PostMapping("/vendors")
	public String saveVendor(Vendor v) {
		vsrv.saveVendor(v);
		session.setAttribute("msg", "Vendor saved successfully");
		return "redirect:/vendors";
	}
	
	@PostMapping("/changepwd")
	public String changepassword(String opwd,String pwd) {		
		if(adminsrv.updatePassword(opwd, pwd)) {
			session.setAttribute("msg", "Password updated successfully");
		}
		else {
			session.setAttribute("error", "Incorrect current password");
		}
		return "redirect:/changepwd";
	}
	
	@GetMapping(path = {"/products","/products/{page}"})
	public String products(@PathVariable("page") Optional<Integer> page,Model model) {
		int pageno=page.isPresent() ? page.get()-1 : 0;
		Page<Product> plist=prodsrv.allProducts(pageno);
		model.addAttribute("prods", plist.toList());
		model.addAttribute("current", pageno+1);
		model.addAttribute("totalpages", plist.getTotalPages());
		model.addAttribute("totalprods", plist.getTotalElements());
		model.addAttribute("cats", catsrv.getAllCategories());
		return "products";
	}
	
	@GetMapping("/delprod/{id}")
	public String deleteproduct(@PathVariable("id") int id) {
		prodsrv.deleteProduct(id);
		session.setAttribute("msg", "Product deleted successfully");
		return "redirect:/products";
	}
	
	@PostMapping("/products")
	public String saveProduct(MultipartFile photo,Product p,String mfg,String expiry) {
		//p.setMfgdate(LocalDate.parse(mfg+"-01"));
		//p.setExpirydate(LocalDate.parse(expiry+"-01"));		

		Category cat=catsrv.findByCatId(p.getCatid());
		p.setCategory(cat);
		System.err.println(p);
		prodsrv.saveProduct(p, photo);
		session.setAttribute("msg", "Product saved successfully");
		return "redirect:/products";
	}
	
	@GetMapping(path = {"/categories","/categories/{id}"})
	public String categories(Model model,@PathVariable("id") Optional<Integer> id) {
		if(id.isPresent()) {
			Category cat=catsrv.findByCatId(id.get());
			model.addAttribute("catid",cat.getCatid());
			model.addAttribute("catname",cat.getCatname());				
		}else {			
			model.addAttribute("catid", catsrv.generateCatId());		
		}
		model.addAttribute("cats", catsrv.getAllCategories());		
		return "category";
	}	

	@PostMapping(path = {"/categories","/categories/{id}"})
	public String saveCategories(Category cat) {
		System.out.println("catid : "+cat.getCatname());
		catsrv.saveCategory(cat);
		session.setAttribute("msg", "Category saved successfully");
		return "redirect:/categories";
	}
	
	@GetMapping("/logout")
	public String logout(){
		session.invalidate();
		return "redirect:/";
	}
}
