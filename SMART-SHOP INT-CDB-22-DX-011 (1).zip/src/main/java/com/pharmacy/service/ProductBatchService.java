package com.pharmacy.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.pharmacy.models.Product;
import com.pharmacy.models.ProductBatch;
import com.pharmacy.repos.ProductBatchRepository;

@Service
public class ProductBatchService {

	@Autowired ProductBatchRepository pbrepo;
	@Autowired ProductService psrv;
	
	public List<ProductBatch> allBatches(){
		return pbrepo.findAll();
	}
	
	public List<ProductBatch> itemsForReport(){
		return pbrepo.findAll(Sort.by(Direction.ASC,"expirydate"))
				.stream().filter(x->x.getQty()>0)
				.collect(Collectors.toList());
	}
	
	public List<ProductBatch> reportItems(){
		return pbrepo.findTop10ByQtyGreaterThanOrderByExpirydate(0);
	}
	
	public List<ProductBatch> itemsToPurchase(){
		return pbrepo.findByPurchase(null);
	}
	
	public List<ProductBatch> findBatchByProductId(int prodid){
		return pbrepo.findByProdid(prodid);
	}
	
	public void saveBatch(ProductBatch pb) {
		Product p=psrv.findProductById(pb.getProdid());
		pb.setProduct(p);
		pbrepo.save(pb);
	}
	
	public void deleteBatch(int bno) {
		ProductBatch pb=pbrepo.findById(bno).get();
		pbrepo.delete(pb);
	}
}
