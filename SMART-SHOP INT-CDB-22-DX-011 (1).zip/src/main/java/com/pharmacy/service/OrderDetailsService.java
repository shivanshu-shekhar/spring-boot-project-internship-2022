package com.pharmacy.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.models.OrderDetails;
import com.pharmacy.models.ProductSalesCount;
import com.pharmacy.repos.OrderDetailsRepository;

@Service
public class OrderDetailsService {

	@Autowired private OrderDetailsRepository odrepo;
	
	public List<OrderDetails> allItemsinOrder(int orderid){
		return odrepo.findByOrderid(orderid);
	}
	
	public void saveItem(OrderDetails od) {		
		odrepo.save(od);
	}
	
	public void deleteAllItems(int orderid) {
		odrepo.deleteByOrderid(orderid);
	}
	
	public Map<String,Long> getChartData(){
		Map<String,Long> map=new HashMap<>();
		for(ProductSalesCount p : odrepo.countProductBySales()) {
			map.put(p.getProduct().getPname(),p.getCount());
		}
		return map;
	}
}
