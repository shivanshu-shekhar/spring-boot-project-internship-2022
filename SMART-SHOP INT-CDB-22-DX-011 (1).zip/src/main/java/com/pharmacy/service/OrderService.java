package com.pharmacy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.pharmacy.models.Cart;
import com.pharmacy.models.Customer;
import com.pharmacy.models.Order;
import com.pharmacy.models.OrderDetails;
import com.pharmacy.models.Product;
import com.pharmacy.models.ProductBatch;
import com.pharmacy.repos.OrderRepository;

@Service
public class OrderService {
	
	@Autowired private OrderRepository orepo;
	@Autowired private CartService cartsrv;
	@Autowired private CustomerService custsrv;
	@Autowired private OrderDetailsService odsrv;
	@Autowired private ProductBatchService pbsrv;
	
	public List<Order> allOrders(){
		return orepo.findAll(Sort.by(Direction.DESC,"id"));
	}
	
	public List<Order> pendingOrders(){
		return orepo.findByStatusOrderByIdDesc("Pending");
	}
	
	public List<Order> allUserOrders(String userid){
		return orepo.findByUseridOrderByIdDesc(userid);
	}
	
	public Order getOrderDetails(int orderid) {
		return orepo.findById(orderid).get();
	}
	
	public void cancelOrder(int orderid) {
		odsrv.deleteAllItems(orderid);
		orepo.deleteById(orderid);
	}
	
	public void confirmOrder(int orderid) {
		
		Order order=orepo.getById(orderid);
		for(OrderDetails od : odsrv.allItemsinOrder(orderid)) {
			Product p=od.getProduct();
			int qtyorder=od.getQty();
			List<ProductBatch> pblist=pbsrv.findBatchByProductId(p.getProdid());
			for(ProductBatch pb : pblist) {
				if(qtyorder<pb.getQty()) {
					pb.setQty(pb.getQty()-qtyorder);
					pbsrv.saveBatch(pb);
					break;
				} else {
					qtyorder-=pb.getQty();
					pb.setQty(0);
					pbsrv.saveBatch(pb);					
				}
			}
		}
		order.setStatus("Confirmed");
		orepo.save(order);
	}
	
	public int placeOrder(Order o,String userid) {
		
		Customer customer=custsrv.findByUserId(userid);
		o.setUserid(userid);
		o.setCustomer(customer);
		Order order=orepo.save(o);
		List<Cart> cartitems=cartsrv.findItemsByUserId(userid);
		for(Cart c : cartitems) {
			OrderDetails od=new OrderDetails();
			od.setOrder(order);
			od.setOrderid(order.getId());
			od.setProduct(c.getProduct());
			od.setQty(c.getQty());
			od.setProdid(c.getProdid());
			od.setPrice(c.getProduct().getProductPrice());
			odsrv.saveItem(od);
		}		
		cartsrv.emptyCart(userid);
		return o.getId();
	}
}
