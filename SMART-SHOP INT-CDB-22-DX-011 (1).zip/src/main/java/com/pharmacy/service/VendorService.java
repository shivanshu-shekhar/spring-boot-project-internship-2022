package com.pharmacy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pharmacy.models.Vendor;
import com.pharmacy.repos.VendorRepository;

@Service
public class VendorService {
	
	@Autowired VendorRepository vrepo;
	
	public void saveVendor(Vendor v) {
		vrepo.save(v);
	}
	
	public List<Vendor> allVendors(){
		return vrepo.findAll();
	}
	
	public Vendor findVendorById(int vid) {
		return vrepo.findById(vid).get();
	}
}
