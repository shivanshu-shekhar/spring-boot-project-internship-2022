package com.pharmacy.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.pharmacy.models.ProductBatch;
import com.pharmacy.models.Purchase;
import com.pharmacy.repos.PurchaseRepository;

@Service
public class PurchaseService {

	@Autowired PurchaseRepository prepo;
	@Autowired VendorService vsrv;
	@Autowired ProductBatchService pbsrv;
	
	public List<Purchase> allPurchases(){
		return prepo.findAll(Sort.by(Direction.DESC, "id"));
	}
	
	public List<Purchase> vendorsPurchases(int vid){
		return prepo.findByVid(vid);
	}
	
	public void savePurchase(Purchase p) {
		p.setVendor(vsrv.findVendorById(p.getVid()));		
		Purchase pur=prepo.save(p);
		for(ProductBatch pb : pbsrv.itemsToPurchase()) {
			pb.setPurchase(pur);			
			pbsrv.saveBatch(pb);
		}
	}
	
}
