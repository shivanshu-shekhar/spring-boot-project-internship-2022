package com.pharmacy;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.pharmacy.models.AdminUser;
import com.pharmacy.repos.AdminRepository;

@SpringBootApplication
@EnableJpaAuditing
public class PharmacyManagementApplication {

	private static final Logger log = LoggerFactory.getLogger(PharmacyManagementApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(PharmacyManagementApplication.class, args);
	}

	@Bean
	public CommandLineRunner demo(AdminRepository repository) {
	    return (args) -> {
	    	if(repository.count()==0) {
	    		repository.save(new AdminUser("admin","admin"));
	    		log.info("Admin user created successfully");
	    	}else {
	    		log.info("Admin user already created");
	    	}
	    };
	}
}
