package com.pharmacy.models;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int prodid;
	private String pname;
	private String company;
	@ManyToOne
	private Category category;
	private String pic;
	private int reorderlevel;
	private int catid;
	private float saleprice;
	private boolean deleted;
	@OneToMany
	@JoinColumn(name="prodid")
	private List<ProductBatch> batches;

	public float getSaleprice() {
		return saleprice;
	}

	public void setSaleprice(float saleprice) {
		this.saleprice = saleprice;
	}

	public float getProductPrice() {
		Optional<ProductBatch> pb=batches.stream()
				.collect(Collectors.maxBy(Comparator.comparing(ProductBatch::getPrice)));
				
		return pb.isPresent() ? pb.get().getPrice() : 0;
	}
	
	public int getProductQty() {
		int qty=batches.stream().collect(Collectors.summingInt(ProductBatch::getQty));
		return qty;
	}
	
	public int getReorderlevel() {
		return reorderlevel;
	}

	public void setReorderlevel(int reorderlevel) {
		this.reorderlevel = reorderlevel;
	}

	public List<ProductBatch> getBatches() {
		return batches;
	}

	public void setBatches(List<ProductBatch> batches) {
		this.batches = batches;
	}

	public boolean isDeleted() {
		return deleted;
	}
	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	
	public int getProdid() {
		return prodid;
	}
	public void setProdid(int prodid) {
		this.prodid = prodid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
	
	
}
