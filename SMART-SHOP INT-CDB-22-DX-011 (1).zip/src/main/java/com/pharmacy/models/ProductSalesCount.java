package com.pharmacy.models;

public class ProductSalesCount {
	private Product product;
	private long count;
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.count = count;
	}
	public ProductSalesCount(Product product, long count) {
		this.product = product;
		this.count = count;
	}
	public ProductSalesCount() {
		// TODO Auto-generated constructor stub
	}
	
	
}
