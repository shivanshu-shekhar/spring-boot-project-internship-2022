package com.pharmacy.models;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

@Entity
public class Category {
	@Id
	private int catid;
	@Column(length = 50)
	private String catname;
	
	@OneToMany
	@JoinColumn(name="catid")
	private Set<Product> products;
	
	public Set<Product> getProducts() {
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}
	public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}
	public String getCatname() {
		return catname;
	}
	public void setCatname(String catname) {
		this.catname = catname;
	}
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public int getTotalProducts() {
		return products.size();
	}
}
