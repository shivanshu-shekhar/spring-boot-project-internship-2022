package com.pharmacy.models;

public class ProductCount {
	//private int catid;
	private Category category;
	private long count;
	
	/*public int getCatid() {
		return catid;
	}
	public void setCatid(int catid) {
		this.catid = catid;
	}*/
	
	
	public long getCount() {
		return count;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public void setCount(long count) {
		this.count = count;
	}
	
	
	
	public ProductCount(Category category, long count) {
		this.category = category;
		this.count = count;
	}
	/*
	 * public ProductCount(int catid, long count) { this.catid = catid; this.count =
	 * count; }
	 */
	public ProductCount() {
		// TODO Auto-generated constructor stub
	}
	
	
}
