package com.pharmacy.models;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Purchase {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private int vid;
	private LocalDate purdate=LocalDate.now();
	
	@ManyToOne
	private Vendor vendor;
	
	@OneToMany
	@JoinColumn(name="id")
	private List<ProductBatch> batches;
	
	public LocalDate getPurdate() {
		return purdate;
	}
	public void setPurdate(LocalDate purdate) {
		this.purdate = purdate;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public Vendor getVendor() {
		return vendor;
	}
	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	public List<ProductBatch> getBatches() {
		return batches;
	}
	public void setBatches(List<ProductBatch> batches) {
		this.batches = batches;
	}
	
	
}
